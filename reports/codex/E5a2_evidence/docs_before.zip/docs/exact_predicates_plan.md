# 换路：精确谓词、浮点只做构造（2026-10-10，G6 第五轮之后）

## 为什么换

M0 的目标是"要么答对、要么报错、绝不静默给错"。几何核此前的做法是**浮点判定 + 噪声带**：每个分支判据都比较一个浮点量与
"它自己的噪声估计"（纪律 F：判据要加被测方向自己的噪声）。五轮独立重审的结果是：

| 轮次 | 确认缺陷 | 其中阈值 / 噪声类 |
|---|---|---|
| 第二轮（09-27） | 两条 critical | 三维棱脊被全局噪声判平、裕度层贯入 fail-unsafe |
| 第三轮（10-10） | 28 条 | 三项"漏了被测方向的噪声"、裕度层两把尺 |
| 第四轮（10-10） | 40 条 | 二维短边法向、G0 三票的两把尺、近平行棱参数 |
| 第五轮（10-10） | 50 条原始（4 critical） | 二维 Minkowski 扫描的宽窗合并 + 链法向、三维棱弧对称和、互锁 n_z 绝对阈值、冻结 EE 朝向、近平行交点的 1/sin²θ 放大、G0 票二票三的分辨带…… |

每补一个带宽，反例就从另一侧钻出来——这与 2026-09 LP 求解器三轮复核的经历完全同构（那次的结论记在
`src/eab/lp.py` 模块文档：浮点单纯形只给候选，有理数精确核验三种证书）。二维浮点凸路径的实测（scratch 扫描，
84 750 个探针）：一般位置的凸对上零错；含 1e-14 … 1e-10 倒角边或 T 形短边的凸对上**静默答反 1 203 次**，答反处真实压入最深约 0.5（半个块）。

## 换成什么

计算几何的标准答案：**精确几何计算**（Exact Geometric Computation，Yap 1997）的 EPIC 形态——**精确谓词、非精确构造**
（CGAL 的 Epick 内核；Shewchuk 1997 的自适应精度谓词）：

1. **所有分支判定**（凸性、法锥有效性、极角序、平行、在不在段内、相交与否）都是输入坐标的低次多项式的**符号**，
   对给定的浮点数据精确求值。E1/E2 先以 `Fraction` 落地；E5a 为 orient3d、二维叉积/点积符号与面内投影加入保守过滤，界内仍退 Fraction，未过滤的路径仍用有理数。精确分类对这组数据唯一正确，不随噪声容差改变。
2. **构造量**（间隙、法向、距离、接触点）照常用浮点算，只当输出，不再拿来做分支。
3. **容差只出现在两个地方**：调用方明说的**域窗口**（如 DDA 的 3° 法锥、1e-6 贴合精度、搜索距离 d0——这是 legacy 的物理约定，
   归 L5 适配器），以及**可分辨性报告**（离判定边界多近、刚体运动后答案会不会变）。E2 兼容接口 `membership_convex` 的 tol=0 返回精确分类；显式 tol>0 可把有距离见证的带内答案报告为 0，不改变带外答案、不抬舍入地板，具体范围见下文。
4. 刚体运动后舍入改变了"恰好相触 / 恰好平行 / 恰好共线"这类**边界态**的答案，那是**数据变了**，不是判定错了。
   不变性门因此改写成两条：(a) 每个答案对精确 oracle 零错（强于原来的"带内跳过"）；(b) 离边界的距离超过舍入噪声时，答案随刚体运动不变。

## 分步

**E5a 执行事件**：确认测试临时文件越出授权工作树，按工单规则整单作废；下表 E5a 实现状态仅供留树审查，不构成有效交付。事件与证据见 `reports/codex/E5a_report.md`。

| 步 | 范围 | 状态 |
|---|---|---|
| E1 | 二维精确层 `kernel2d/exact.py`：精确凸性、精确 E = B ⊕ (−A)（只合并精确平行）、精确成员、精确分离轴 oracle、精确法锥判据、一般简单多边形的精确相交 | 已写，门 `tests/test_kernel2d_exact.py` |
| E2 | 二维凸路径接精确层：凸性/极角/平行/成员/法锥精确；facet gap 只作构造量；G0 三票零容差、不跳样本；删除方向可行窗/链法向；凸首入选路、初态与射线裁剪也用精确 facet | WO-E2 已验收合入 `e1fbbd4`（2026-10-12 工单确认；全套 7500 passed）：`tests/test_kernel2d_exact.py`、`tests/test_kernel2d_report_band.py`、`tests/test_kernel2d_convex_ray_exact.py` 及改写后的二维回归/不变性门。全套、耗时与突变结果见 `reports/codex/E2_report.md`；不等于 G6 退出 |
| E3 | 二维剩余首入、局部 VE/EV/VV、边内与凸包 | WO-E3E4 实现并配门（2026-10-12，待所有者验收/G6）：凹初态/仿射根/段内/相交/漏候选自检在 Fraction 上做，局部出口按精确平方距离选最浅盖；精确并列与 near_labels 分开；显式域窗不抬噪声地板。`test_kernel2d_entrance_e3.py`、`test_kernel2d_covers_e3.py`，全套与突变证据见 `reports/codex/E3E4_report.md` |
| E4 | 极限分析有理数自校验 | WO-E3E4 实现并配门（2026-10-12，待所有者验收/G6）：LP 解保留有理数见证，静力/对偶/互补/容许性精确核同一模型；多体可分辨性按本体形心/臂长，风险只报 resolvability/statuses，不改变原问题精确 status/alpha；原筛查测试保留输入并加强为精确答案与风险报告双门。`test_limit_exact_selfcheck.py`、既有 selfcheck/multi 门及源码突变；10⁻¹⁰⁰ 注入用 Fraction 保持可表达性，浮点已舍入成原值时不能声称能识别未表达的差异 |
| E5 | 三维：凸体按顶点集的精确凸包表示（微二面角是真棱），棱弧 / 顶点锥 / 交点参数精确；G0 三维三票为定理检验 | **WO-E5a 部分实现，未验收、未过 G6**：精确凸包/共面归并、显式精确三角表面原语、局部盖符号与凸成员、G0 三票零跳样零豁免、保守过滤已有门。一般旧 `polyhedra_overlap` / `point_in_polyhedron` / `segment_crosses_face` 入口尚未全量迁移，不能称三维几何核已全部精确。设计 `docs/exact_3d_design.md`，实测、突变与遗漏 `reports/codex/E5a_report.md`。E5b 的 margin/entrance3/interlock/frozen 完整精确化仍未做 |

每一步都配精确 oracle（与被测路径零共用）与突变体；对 legacy 的对账（bb52 的 3° / 1e-6）走显式的域窗口，不受影响。

### E2 的已实现范围与未实现边界

- 凸输入只接受精确凸，平直顶点允许，零长边/反射/折回/绕圈清晰拒收。刚体舍入造成微凹时不能继续当凸；成员回退到一般简单多边形精确相交，首入切到既有凹路径。门 `test_rounded_flat_vertex_is_refused_by_the_convex_path`、`test_first_entrance_routes_rounded_reflex_input_away_from_the_convex_path`。
- G0 票二用独立全顶点投影支撑 oracle 分别核对严格与边界集合，平直链不能简化成“非 FF 就严格”；票三用独立 Fraction 凸包只数严格顶点。门 `test_g0_flat_chains_use_exact_support_sets_without_ambiguity_exemptions`、`test_g0_support_and_hull_oracles_use_no_tested_geometry_primitive`（均在 `test_kernel2d_exact.py`）。
- `membership_convex` 的显式报告带：凸对用精确闭线段距离检验完整欧氏边界带；非凸对只在四轴 ±tol 的精确状态变化给出边界见证时报告 0，**保守但不完备**，未检出的带内点保留精确分类。带外不能吞成 0。门 `test_kernel2d_report_band.py`；完整非凸 E 边界距离留待后续全局构造。
- E2 当时未修改局部单盖、凹候选和局部出口；E3 已补，见上表与 WO-E3E4 报告。没有实现凹块全局 E/盖裁剪，shortest_exit 不声称凹对全局最小分离。

## 不能主张的

- 精确谓词保证的是"对这组浮点数据答对"，不是"对数据背后那个理想几何答对"——舍入已经发生在输入里；
- 构造量（间隙、法向）仍是浮点，误差界另算；
- 速度：E5a 已有部分经对拍与缩界突变验证的浮点过滤；不是所有 Fraction 路径都有快路，更不能从微基准推断全套达到 600 秒。以 `reports/codex/E5a_report.md` 的独立整套实测为准。

### E5a 的几何模型边界

- 显式凸 API 定义对象为输入顶点的精确凸包。非共面源四边形可能分裂，标签属于 canonical convex view，`source_vertices` / `source_faces` 记录来源；一般单盖仍按源面编号，二者不得混用。
- `g03_exact.py` 用独立整数/有理算术凸包、SAT 和支撑集作 oracle，先保存原输入再调用被测凸化路径。边界探针覆盖 E 的全部顶点、棱中点、面重心，不以 ambiguous / low_e 豁免。门 `test_g03_e5a.py`、`test_covers3_g0_vote2.py`。
- 一般多边形面上的单盖暂以精确 Newell 面向量解释局部法锥，不是完整折面实体语义。新 `exact_*` 表面原语不等于旧入口已接通；凹块全局 E、一般精确实体相交及 E5b 的完整迁移仍未完成。
- `membership_convex3(tol=0)` 为精确三分；显式正 tol 保留支撑平面距离带，不是完整欧氏偏移体。`enumerate_covers3` 外层浮点 gap 搜索窗仍为遗留适配点。
