"""E2 凸首入：不以浮点 facet_gap 作任何命中或时刻分支。

旧口径用两次间隙之差求斜率并把1e-12速度夹平；新门用方块闭式区间及内联 Fraction SAT 射线裁剪，
与被测 Minkowski 边归并/法向/gap 零共用原语。容差只许影响并列标签，不许把带外射线变成命中。
"""
from construction_oracle import scalar_exact
import math
import random
from fractions import Fraction as F

import pytest

from eab.kernel2d.entrance import first_entrance

SQ = [(0., 0.), (1., 0.), (1., 1.), (0., 1.)]


@pytest.mark.parametrize('scale', [2.**-10, 1., 2.**10])
@pytest.mark.parametrize('offset', [0., 1e3, 1e6])
def test_convex_ray_resolves_tiny_slopes_and_misses(scale, offset):
    """闭式E=[-s,s]^2：极小但非零速度必须命中；仅一个ulp错过也不得由tol吸收。"""
    sq = [(offset + scale * x, -offset + scale * y) for x, y in SQ]
    speed = scale * 2.**-45
    got = first_entrance(sq, sq, (2 * scale, 0.), (-speed, 0.))
    assert got.kind == 'entrance' and got.t == 2.**45
    assert got.x == (scale, 0.)
    for tol in (0., scale):
        miss = first_entrance(sq, sq, (2 * scale, math.nextafter(scale, math.inf)), (-scale, 0.), tol=tol)
        assert miss.kind == 'none'
        short = first_entrance(sq, sq, (2 * scale, 0.), (-scale, 0.), t_max=math.nextafter(1., 0.), tol=tol)
        assert short.kind == 'none'


def test_convex_ray_decisions_do_not_use_constructed_facet_gaps(monkeypatch):
    """源路径gap被毒化为错误常数，只能改变报告gap，不得改变kind/t/label；断言穿过真实裁剪路径。"""
    from eab.kernel2d import entrance
    ref = first_entrance(SQ, SQ, (2., .25), (-1., 0.))
    monkeypatch.setattr(entrance, 'facet_gap', lambda *a: -999.)
    got = first_entrance(SQ, SQ, (2., .25), (-1., 0.))
    assert (got.kind, got.t, got.label, got.x) == (ref.kind, 1., ref.label, (1., .25))
    assert got.gap == -999.


@pytest.mark.parametrize('direction', [(1., 0.), (0., 1.), (-1., 0.)])
def test_touching_start_is_first_contact_at_zero_even_when_moving_away(direction):
    """闭集定义min{t>=0:x(t)∈E}在初始接触时恒为0，不依赖进入型facet存在。"""
    got = first_entrance(SQ, SQ, (1., 0.), direction)
    assert got.kind == 'entrance' and got.t == 0.


@pytest.mark.parametrize('direction', [(1., 1.), (1., 0.), (-1., -1.)])
def test_corner_start_reports_both_exact_active_facets(direction):
    """闭式E角点(1,1)同时活动右/上两侧，背离或切向运动也不能漏报集值标签。"""
    got = first_entrance(SQ, SQ, (1., 1.), direction)
    assert got.kind == 'entrance' and got.t == 0.
    assert set(got.tied_labels) == {('FF', 3, 1), ('FF', 0, 2)}


def _sat_ray(A, B, x, d):
    """独立全投影SAT：在原始两个凸体边法向上求投影区间首次相交，内联有理数，无Minkowski原语。"""
    A, B = [[(F(u), F(v)) for u, v in P] for P in (A, B)]
    X, D = tuple((F(_r12_item) for _r12_item in x)), tuple((F(_r12_item) for _r12_item in d))
    low, high = F(0), None
    for P in (A, B):
        for i, p in enumerate(P):
            q = P[(i + 1) % len(P)]
            nx, ny = q[1] - p[1], p[0] - q[0]
            ap = [nx * (a[0] + X[0]) + ny * (a[1] + X[1]) for a in A]
            bp = [nx * b[0] + ny * b[1] for b in B]
            speed = nx * D[0] + ny * D[1]
            lower, upper = min(bp) - max(ap), max(bp) - min(ap)
            if speed == 0:
                if lower > 0 or upper < 0:
                    return None
                continue
            lo, hi = sorted((lower / speed, upper / speed))
            low = max(low, lo)
            high = hi if high is None else min(high, hi)
    return None if high is not None and low > high else low


@pytest.mark.parametrize('seed', range(8))
@pytest.mark.parametrize('offset', [0., 1e3, 1e6])
def test_convex_ray_time_matches_independent_fraction_sat(seed, offset):
    rng = random.Random(802 + seed)
    theta = rng.uniform(.1, 5.)
    scale = (2.**-10, 1., 2.**10)[seed % 3]
    c, sn = math.cos(theta), math.sin(theta)
    transform = lambda P: [(offset + scale * (c*u - sn*v), -.7*offset + scale * (sn*u+c*v)) for u,v in P]
    A = transform([(0., 0.), (.7, .1), (.2, .8)])
    B = transform([(0., 0.), (1.5, 0.), (1., 1.2), (0., 1.)])
    x = (scale * 4., scale * 3.)
    d = (scale * -2., scale * rng.uniform(-2., -.5))
    want = _sat_ray(A, B, x, d)
    got = first_entrance(A, B, x, d)
    if want is None:
        assert got.kind == 'none'
    else:
        assert got.kind == 'entrance' and got.t == scalar_exact(want)
