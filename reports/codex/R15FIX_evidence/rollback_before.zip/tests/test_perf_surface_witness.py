"""Exact arrangement early-exit equivalence, against frozen pre-PERF function.

This reference deliberately shares arithmetic/membership primitives: it verifies
optimization equivalence, not an independent G0 geometry certificate.
"""
from fractions import Fraction as F
import inspect
import random
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))

import pytest

from eab.kernel3d import exact_geom as G
from eab.kernel3d.geom3 import Polyhedron, box, tetra
from perf_witness_reference import reference_witness


def _inputs(case):
    rng = random.Random(48201)
    rows = [(box(), box().translated(off)) for off in (
        (0, 0, 0), (2, 0, 0), (2, 2, 0), (2, 2, 2),
        (F(3, 10), F(7, 10), F(-1, 5)), (3, 0, 0))]
    for _ in range(6):
        off = tuple(F(rng.randrange(-10, 11), 8) for _ in range(3))
        rows.append((box(), box().translated(off)))
    for _ in range(4):
        A = tetra((0, 0, 0), (F(3, 2), 0, 0), (F(1, 3), 1, 0),
                  (F(-1, 4), F(1, 7), F(1, 1 << rng.randrange(1, 14))))
        off = tuple(F(rng.randrange(-4, 5), 8) for _ in range(3))
        rows.append((A, A.translated(off)))
    from osteomorphic import interlocking_pair
    A, B = interlocking_pair(nx=3, ny=1, amp=.3, phase=.7)
    rows.extend((A.translated(off), B) for off in (
        (0., 0., 0.), (.23, .07, 0.), (-.1, .12, .04), (.4, 0., 0.)))
    return rows[case]


def _transform(P, engineering):
    if not engineering:
        return P
    s, t = F(1, 1000), F(10**6)
    # Exact non-axis-aligned rotation; a reflection would invalidate orientation.
    return Polyhedron([(t+s*(F(3, 5)*F(x)-F(4, 5)*F(y)),
                        -t+s*(F(4, 5)*F(x)+F(3, 5)*F(y)),
                        t+s*F(z)) for x, y, z in P.verts], list(P.faces))


def _args(A, B):
    at, bt = G.triangles(A), G.triangles(B)
    return at, bt, G._planes(at), G._planes(bt)


@pytest.mark.parametrize('case', range(20))
@pytest.mark.parametrize('engineering', (False, True))
def test_arrangement_pruning_preserves_exact_first_witness(case, engineering):
    A, B = (_transform(P, engineering) for P in _inputs(case))
    args = _args(A, B)
    assert G._surface_interior_witness(*args) == reference_witness(*args)


def test_arrangement_aabb_is_closed_and_mutation_removing_boundary_has_teeth():
    args = _args(box(), box())
    expected = reference_witness(*args)
    assert expected is not None, 'identical bodies have a coplanar inward witness'
    assert G._surface_interior_witness(*args) == expected
    source = inspect.getsource(G._surface_interior_witness)
    needle = 'max(v[i] for v in tri)<lo or min(v[i] for v in tri)>hi'
    assert needle in source
    mutated = source.replace(needle, 'max(v[i] for v in tri)<=lo or min(v[i] for v in tri)>=hi')
    namespace = dict(G.__dict__)
    exec(mutated, namespace)
    with pytest.raises(AssertionError, match='coplanar witness must survive'):
        assert namespace['_surface_interior_witness'](*args) == expected, 'coplanar witness must survive'


def test_arrangement_source_plane_sign_mutation_is_caught_by_first_witness():
    args = _args(box(), box().translated((F(3, 10), F(7, 10), F(-1, 5))))
    expected = reference_witness(*args)
    assert expected is not None, 'nontrivial partial intersection must have a witness'
    assert G._surface_interior_witness(*args) == expected
    source = inspect.getsource(G._surface_interior_witness)
    needle = 'min(source_sides)>=0 or max(source_sides)<=0'
    assert needle in source
    mutated = source.replace(needle, 'min(source_sides)<=0 or max(source_sides)>=0')
    namespace = dict(G.__dict__)
    exec(mutated, namespace)
    with pytest.raises(AssertionError, match='first exact witness changed'):
        assert namespace['_surface_interior_witness'](*args) == expected, 'first exact witness changed'


def test_coplanar_grouping_keeps_the_plane_offset_not_only_its_direction():
    args = _args(*_inputs(9))
    expected = reference_witness(*args)
    assert expected == (F(-3, 32), F(-7, 16), F(1, 8))
    assert G._surface_interior_witness(*args) == expected
    source = inspect.getsource(G._surface_interior_witness)
    assert 'coplanar.setdefault(plane,[])' in source
    assert 'coplanar.get((key,dot(key,o)),())' in source
    # Corrupt only the coplanar grouping, not the supporting-plane dedup map.
    mutated = source.replace('coplanar.setdefault(plane,[])', 'coplanar.setdefault(plane[0],[])')
    mutated = mutated.replace('coplanar.get((key,dot(key,o)),())', 'coplanar.get(key,())')
    namespace = dict(G.__dict__)
    exec(mutated, namespace)
    with pytest.raises(AssertionError, match='parallel planes are not coplanar'):
        assert namespace['_surface_interior_witness'](*args) == expected, 'parallel planes are not coplanar'
