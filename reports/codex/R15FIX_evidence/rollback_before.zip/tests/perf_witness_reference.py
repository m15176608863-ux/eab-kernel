"""WO-PERF arrangement equivalence reference; shared exact primitives, not a G0 oracle."""
from eab.kernel3d.exact_geom import (
    _triangle_bounds, cross, dot, sub, _direction_key, _split_polygon,
    _point_in_triangles, _inward_sample, _coplanar_interior_witness,
)

def reference_witness(at,bt,ap,bp):
    """Finite complete boundary-patch certificate for valid closed surfaces.

    Each input triangle is split by every other triangle's plane, and by edge
    lines of triangles coplanar with it. Membership is constant on every open
    2D cell. A nonempty bounded 3D intersection has an open boundary patch on
    one input surface: either that patch is inside the other solid, or the
    two boundaries coincide there and their inward sides agree. Thus these
    cells exhaust the possibilities, including common-edge and coplanar cases.
    Rational points strictly inside both solids are the returned certificates.
    """
    planes=ap+bp
    for pt,qt,pp,qp in ((at,bt,ap,bp),(bt,at,bp,ap)):
        pb,qb=_triangle_bounds(pt),_triangle_bounds(qt)
        for (_,tri),(n,o) in zip(pt,pp):
            cuts=list(qp)
            for (_,other),(m,a) in zip(qt,qp):
                if not any(cross(n,m)) and dot(n,sub(a,o)) == 0:
                    cuts.extend((cross(n,sub(v,u)),u)
                                for u,v in zip(other,other[1:]+other[:1]))
            # Repeated supporting planes cannot refine the arrangement again.
            unique={}
            for m,a in cuts:
                key=_direction_key(m)
                if key is not None:
                    unique[(key,dot(key,a))]=(m,a)
            cells=[list(tri)]
            for m,a in unique.values():
                cells=[part for cell in cells for part in _split_polygon(cell,m,a)]
            for cell in cells:
                p=tuple(sum(v[i] for v in cell)/len(cell) for i in range(3))
                loc=_point_in_triangles(p,qt,qp,qb)
                if loc == 1:
                    w=_inward_sample(p,n,planes)
                    if _point_in_triangles(w,pt,pp,pb) == _point_in_triangles(w,qt,qp,qb) == 1:
                        return w
                elif loc == 0:
                    witness=_coplanar_interior_witness(p,n,pt,qt,planes,pp,qp,pb,qb)
                    if witness is not None:
                        return witness
    return None

