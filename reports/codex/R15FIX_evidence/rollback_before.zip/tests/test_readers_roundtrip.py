"""读取器门：对入库夹具 (1) 解析非空 (2) 两次解析逐字节同一 (3) JSON 往返恒等 (4) 契约校验全过
(5) canonical_key 块序交换不变 (6) 身份可解析的来源（bdda_df 有 verts.csv、bdda3d）逐步键唯一。

旧版 (5) 处是 `len(keys) == len(records)`——列表推导式的长度恒等于输入长度，同义反复（审查 C20）。
夹具缺失时 skip（夹具由 tools/ingest_fixtures.py / tools/ingest_bdda3d.py 生成）。
"""
from construction_oracle import scalar_exact

import dataclasses
from pathlib import Path

import pytest

from eab import records_from_json, records_to_json, validate
from eab.readers import bdda3d, bdda_df, tf_probe

FIX = Path(__file__).resolve().parents[1] / "fixtures"


def _swapped(r):
    return dataclasses.replace(r, block_a=r.block_b, block_b=r.block_a, feature_a=r.feature_b, feature_b=r.feature_a)


def _gate(records, parse_again):
    assert len(records) > 0
    text = records_to_json(records)
    assert records_to_json(parse_again()) == text          # 确定性
    assert records_from_json(text) == records              # 往返恒等
    for r in records:
        validate(r)
        k = r.canonical_key()
        hash(k)
        assert _swapped(r).canonical_key() == k            # 块序交换不变（真实数据上）
    return text


def _assert_step_keys_unique(records):
    seen = {}
    for r in records:
        key = (r.step, r.canonical_key())
        assert key not in seen, ("同一步两条记录撞键", seen[key], r.contact_index, key)
        seen[key] = r.contact_index


_M4_DUPLICATE_CONTACTS = {
    "bbv01_N3": [(1, (53, 54)), (1, (104, 107)), (1, (129, 130))],
    "bbv01_dbv01a_N3": [(1, (53, 54)), (1, (127, 128))],
    "bbv02_N3": [(1, (1, 2)), (1, (61, 62))],
    "bbv02_dbv02a_N3": [(1, (1, 2)), (1, (61, 62))],
}


def _primary_unique_records(records, expected_duplicates=()):
    """M4 原始重复不删行：仅 9 个钉死组允许主键相同，未知重复必红。"""
    groups = {}
    for r in records:
        groups.setdefault((r.step, r.canonical_key()), []).append(r)
    duplicates = sorted((step, tuple(r.contact_index for r in rs))
                        for (step, _), rs in groups.items() if len(rs) > 1)
    assert duplicates == list(expected_duplicates), ("unexpected primary duplicates", duplicates)
    for rs in groups.values():
        if len(rs) < 2:
            continue
        # 只接纳原始主三点相同而第二参考不同的这批表示，不豁免 alias 撞键。
        assert len({tuple(r.extra[k] for k in ("raw_p1", "raw_p2", "p3")) for r in rs}) == 1
        assert len({tuple(r.extra[k] for k in ("m4", "m5", "m6")) for r in rs}) == len(rs)
    return [rs[0] for rs in groups.values()]

@pytest.mark.parametrize("case_dir", sorted((FIX / "bdda_df").glob("*")) if (FIX / "bdda_df").exists() else [])
def test_bdda_df_fixture(case_dir):
    recs = bdda_df.load_records(case_dir)
    _gate(recs, lambda: bdda_df.load_records(case_dir))
    # 主表每步每接触一行 → (step, contact) 唯一
    assert len({(r.step, r.contact_index) for r in recs}) == len(recs)
    # 块号全部可解析（verts.csv 在时靠顶点号补全），且 verts 与 df18 两路块号零冲突
    if (case_dir / "bdda_debug_verts.csv").exists():
        assert not any(r.extra.get("_blocks_unknown") for r in recs)
    assert not any(r.extra.get("_block_mismatch") for r in recs)
    # 身份（两个特征）可解析的记录逐步键唯一；缺 verts.csv 的夹具里块号未知的记录没有特征，键只到块对级
    resolved = [r for r in recs if r.feature_a is not None and r.feature_b is not None]
    if (case_dir / "bdda_debug_verts.csv").exists():
        assert len(resolved) == len(recs)
    assert all(r.extra.get("_blocks_unknown") for r in recs if r not in resolved)
    _assert_step_keys_unique(_primary_unique_records(resolved, _M4_DUPLICATE_CONTACTS.get(case_dir.name, ())))


@pytest.mark.parametrize("probe", sorted((FIX / "tf").glob("*/retry_contact_pair_probe.tsv")) if (FIX / "tf").exists() else [])
def test_tf_probe_fixture(probe):
    recs = tf_probe.load_records(probe)
    _gate(recs, lambda: tf_probe.load_records(probe))
    assert all(r.cover.value in ("VF", "EE", "NN", "NE") for r in recs)
    # tf 探针不带特征：canonical_key 只到块对级（契约文档写明），不做逐步唯一断言
    assert all(r.feature_a is None and r.feature_b is None and r.canonical_key()[3] == () for r in recs)


@pytest.mark.parametrize("stage", sorted((FIX / "tf").glob("*/contact_pair_stage.tsv")) if (FIX / "tf").exists() else [])
def test_tf_pair_stage_fixture(stage):
    rows = tf_probe.read_pair_stage(stage)
    assert rows
    for r in rows:
        assert r.total_contacts == r.nn_count + r.ne_count + r.np_count + r.ee_count
        assert r.contact_end - r.contact_start == r.total_contacts


@pytest.mark.parametrize("js", sorted((FIX / "bdda3d").glob("*.json")) if (FIX / "bdda3d").exists() else [])
def test_bdda3d_fixture(js):
    recs = bdda3d.load_records(js)
    _gate(recs, lambda: bdda3d.load_records(js))
    assert all(r.cover.value in ("VF", "EE") for r in recs)
    assert all(r.feature_a is not None and r.feature_b is not None for r in recs)
    assert all(r.feature_b.verts for r in recs if r.cover.value == "VF")   # 面身份 = 顶点三元组，不是 −1
    _assert_step_keys_unique(recs)


def _key_constant(orig):
    return lambda self: ("const",)


def _key_ignores_features(orig):
    return lambda self: orig(self)[:3] + ((),)


def _key_not_swap_symmetric(orig):
    return lambda self: (self.block_a, self.block_b) + orig(self)[2:]


_KEYED = ([p for p in sorted((FIX / "bdda3d").glob("*.json"))] if (FIX / "bdda3d").exists() else []) + \
         ([p for p in sorted((FIX / "bdda_df").glob("*")) if (p / "bdda_debug_verts.csv").exists()]
          if (FIX / "bdda_df").exists() else [])


@pytest.mark.parametrize("src", _KEYED, ids=lambda p: f"{p.parent.name}/{p.name}")
@pytest.mark.parametrize("mut", [_key_constant, _key_ignores_features, _key_not_swap_symmetric],
                         ids=["constant_key", "key_ignores_features", "key_not_swap_symmetric"])
def test_reader_key_gate_has_teeth_where_the_retired_assert_had_none(monkeypatch, src, mut):
    """审查 C20 的证据钉成门：三种 canonical_key 退化（常量键、键丢特征、键不对称）下，
    被删的 `len([k for r in recs]) == len(recs)` 恒真（同义反复，删掉不算放松），
    而现在的门（块序交换不变 + 逐步键唯一）必红。"""
    import eab.contact_record as cr
    recs = bdda3d.load_records(src) if src.suffix == ".json" else bdda_df.load_records(src)
    recs = _primary_unique_records(recs, _M4_DUPLICATE_CONTACTS.get(src.name, ()))
    monkeypatch.setattr(cr.ContactRecord, "canonical_key", mut(cr.ContactRecord.canonical_key))
    keys = [r.canonical_key() for r in recs]
    assert len(keys) == len(recs)                              # 旧断言：退化下照样绿
    with pytest.raises(AssertionError):
        for r in recs:
            assert _swapped(r).canonical_key() == r.canonical_key()
        _assert_step_keys_unique([r for r in recs if r.feature_a is not None and r.feature_b is not None])


# ---------------------------------------------------------------- G6 minor 30：bdda_df 的特征顶点号经 alias 规范化

_DF_WITH_VERTS = [p for p in sorted((FIX / "bdda_df").glob("*")) if (p / "bdda_debug_verts.csv").exists()] \
    if (FIX / "bdda_df").exists() else []


def _raw_contacts(case_dir):
    """独立解析 contacts.csv（不用 csv 模块、不用 bdda_df）：(step, contact) -> {p1, p2}。"""
    lines = [ln for ln in (case_dir / "bdda_debug_contacts.csv").read_bytes().decode("utf-8")
             .replace("\r\n", "\n").split("\n") if ln]
    head = lines[0].split(",")
    out = {}
    for ln in lines[1:]:
        d = dict(zip(head, ln.split(",")))
        out[(int(d["step"]), int(d["contact"]))] = {"p1": int(d["p1"]), "p2": int(d["p2"]), "p3": int(scalar_exact(d["p3"])),
                                                     "mtype": int(scalar_exact(d["mtype"])),
                                                     **{k: int(scalar_exact(d[k])) for k in ("m4", "m5", "m6")}}
    return out


@pytest.mark.parametrize("case_dir", _DF_WITH_VERTS, ids=lambda p: p.name)
def test_bdda_df_feature_ids_are_in_the_loaded_polygon(case_dir):
    """G6 minor 30（C20 只修了一半）：feature_b.index 曾是 legacy 的原始 p2——120/540（bb52_N10）、323/988（bbW025_N10）、
    40/40（bbF038_N20）、24/108（studio_20260712）是 df 回绕尾巴的重复顶点号，**不在**该块载入后的多边形里，
    由载入多边形造出的内核盖不可能带着它们，跨引擎集合同构就对不上。现在有 verts.csv 时经 StepGeometry.canon
    规范化；原始值留 extra['raw_p1'] / extra['raw_p2']，与 contacts.csv 独立解析的值逐条相等（读取器不丢信息）。"""
    from eab.readers.bdda_geom import load_step_geometries
    recs = bdda_df.load_records(case_dir)
    geoms = load_step_geometries(case_dir / "bdda_debug_verts.csv")
    raw = _raw_contacts(case_dir)
    bad = [(r.step, r.contact_index, f) for r in recs for f in (r.feature_a, r.feature_b)
           if f.index not in geoms[r.step].blocks[f.block].vidx]
    assert bad == [], (len(bad), len(recs), bad[:3])
    for r in recs:
        sg, want = geoms[r.step], raw[(r.step, r.contact_index)]
        assert (r.extra["raw_p1"], r.extra["raw_p2"]) == (want["p1"], want["p2"])
        assert r.feature_a.index == sg.canon(want["p1"])
        assert r.feature_b.index in (sg.canon(want["p2"]), sg.canon(want["p3"]))


@pytest.mark.parametrize("case_dir", _DF_WITH_VERTS, ids=lambda p: p.name)
def test_bdda_df_feature_b_follows_the_kernel_naming(case_dir):
    """G6 第二轮 minor：feature_b 曾一律是 Feature(块, 'edge', p2)——p2 是 legacy 边 p3→p2 的**终点**，内核与 bb52_g0
    都以起点命名边；v-v 记录（mtype 1）的 B 特征还被标成 edge。现在：v-e 记录的 feature_b 是边 {p2, p3} 在载入后
    CCW 多边形里的起点（它在环上的后继就是另一端点），v-v 记录是双参考共享的真实顶点，不是固定 p2。"""
    from eab.kernel2d.geom import signed_area
    from eab.readers.bdda_geom import load_step_geometries
    recs = bdda_df.load_records(case_dir)
    geoms = load_step_geometries(case_dir / "bdda_debug_verts.csv")
    raw = _raw_contacts(case_dir)
    kinds = {0: 0, 1: 0}
    for r in recs:
        sg, want = geoms[r.step], raw[(r.step, r.contact_index)]
        g = sg.blocks[r.feature_b.block]
        assert signed_area(g.poly) > 0.0
        kinds[want["mtype"]] += 1
        if want["mtype"] == 1:
            shared = ({sg.canon(want[k]) for k in ("p1", "p2", "p3")}
                      & {sg.canon(want[k]) for k in ("m4", "m5", "m6")})
            candidates = shared & set(g.vidx)
            assert len(candidates) == 1
            assert (r.feature_b.kind, r.feature_b.index) == ("vertex", candidates.pop()), r
            continue
        assert r.feature_b.kind == "edge" and "_edge_not_adjacent" not in r.extra, r
        i = g.vidx.index(r.feature_b.index)
        succ = g.vidx[(i + 1) % len(g.vidx)]
        assert {r.feature_b.index, succ} == {sg.canon(want["p2"]), sg.canon(want["p3"])}, (r.step, r.contact_index)
    assert kinds[0] > 0


def test_bdda_df_feature_b_covers_both_contact_kinds():
    """上面的门在 v-v 一侧不空：bb52_N10、bbW025_N10、studio 各有 v-v 记录。"""
    n_vv = sum(1 for d in _DF_WITH_VERTS for w in _raw_contacts(d).values() if w["mtype"] == 1)
    assert n_vv >= 20, n_vv


@pytest.mark.parametrize("name", ["studio_20260712", "sensor_20260624"])
def test_bdda_df_state_fields_come_only_from_df22(name):
    """G6 第二轮 minor：某 (step, contact) 没有 df22 行时，旧版把 contacts.csv 的转移态（m0_2 / o3 / o4）抄进 mode / gap /
    shear，studio 与 sensor 第 2 步 54/54 条记录把上一步的携带值报成本步状态、无任何标记。现在状态字段留空，
    携带值只在 mode_init / gap_ref / slip_ref。"""
    from eab.contact_record import Mode
    case_dir = FIX / "bdda_df" / name
    if not case_dir.exists():
        pytest.skip("fixture missing")
    recs = bdda_df.load_records(case_dir)
    missing = [r for r in recs if "df22_oc_iter" not in r.extra]
    assert len(missing) >= 54, len(missing)
    for r in missing:
        assert (r.mode, r.raw_mode, r.gap, r.shear, r.mode_prev) == (Mode.UNKNOWN, None, None, None, None), r
        assert r.mode_init is not None and r.gap_ref is not None and r.slip_ref is not None, r
    assert any(r.mode != Mode.UNKNOWN for r in recs if "df22_oc_iter" in r.extra)


def test_bdda3d_state_fields_are_empty_without_a_per_step_judgment():
    """G6 第三轮 minor：3-b-dda 的入口 dict 只有转移进来的 m0init，没有本步开闭判定——mode 必须留 UNKNOWN、raw_mode 留空，
    携带值只在 mode_init（与 bdda_df 缺 df22 时同一口径）。"""
    from eab.contact_record import Mode
    p = FIX / "bdda3d" / "cb2_locked.json"
    if not p.exists():
        pytest.skip("fixture missing")
    recs = bdda3d.load_records(p)
    assert recs and all(r.mode == Mode.UNKNOWN and r.raw_mode is None for r in recs)
    assert all(r.mode_init is not None and r.raw_mode_init is not None for r in recs)
