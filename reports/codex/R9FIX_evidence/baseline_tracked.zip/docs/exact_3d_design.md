# WO-E5a 三维精确几何设计（实现前冻结，2026-10-12）

> **WO-R8FIX（2026-10-12，修复留树，待独立 G6）**：本轮 G6H 确认 6 条 major；逐条红绿、内部变异、旧门对照、同类扫描和全套实测见 [R8FIX 报告](file:///D:/eab-wt/cx-e2/reports/codex/R8FIX_report.md)。当前合同补充见 [R8FIX 设计同步](file:///D:/eab-wt/cx-e2/docs/r8fix_design_sync.md)。本树同步不等于只读外部正本已回写；M0 退出状态不升级。

> **WO-R6FIX（2026-10-12，修复留树，待独立复核）**：第六轮确认 12 条（1 critical / 7 major / 4 minor），原审查见 [G6F 输入](file:///D:/eab-wt/cx-e2/reports/codex/inputs/G6F_report.md)。修复、修前红/修后绿、内部变异、同类扫描和完整测试结果统一见 [R6FIX 报告](file:///D:/eab-wt/cx-e2/reports/codex/R6FIX_report.md)。本次本树测试不等于独立六路 G6，且按工单禁止创建 worktree；M0 退出状态不升级。


> **E5 已完成（窗口为局部贯入厚度口径，WO-PERF 所有者定稿）**：保留兼容参数名 `contact_window`；它不是整体最短分离平移的欧氏贯入深度 PD 阈值。贯入相触报告只承诺“六轴非贯入证书 ⇒ rho ≤ w”或“星核薄壳证书 ⇒ 每个重叠区位于径向厚度 ≤ w 的壳内”。这里 `rho = inf{||d||₂ : int(A+d)∩int(B)=∅}`；正本 01 的 `PD_closed = inf{||d||₂ : (A+d)∩B=∅}` 是闭集完全分离的下确界，两者对一般闭表面不相同，六轴不保证 PD_closed≤w；报贯入也不推出 PD_closed>w。六轴及 L1 壳构造依赖坐标系，斜向短脱离可能漏，不保证旋转不变性。默认精确路径不使用该政策。闭合空腔反例门 `test_r7fix_docs.py::test_g6g09_tight_closed_cavity_distinguishes_rho_from_pd_closed` 固定两种口径；其他独立 oracle、限制反例与内部突变门见 [窗口门](file:///D:/eab-wt/cx-e2/tests/test_perf_contact_window.py)，定稿与性能证据见 [WO-PERF 报告](file:///D:/eab-wt/cx-e2/reports/codex/PERF_report.md)。此“已完成”指工单契约项，不冒充未经执行的独立六路 G6。


> **WO-E5b（2026-10-12，工作树实现，未经 G6）**：默认按给定数据精确判定，`contact_window=None` 不含隐式 ctol；显式窗口是调用方的局部贯入厚度报告政策（非 PD）。精确运动事件与证明读取 `exact_height` / `exact_offset`（互锁）和 `exact_t` / `surface_label`（首入），不能将浮点显示高度再逐顶点舍入后当作同一证书。当前验收、窗口数学定义、全部原格迁移与残余限制以 [E5b 报告](file:///D:/eab-wt/cx-e2/reports/codex/E5b_report.md) 和 [三维设计](file:///D:/eab-wt/cx-e2/docs/exact_3d_design.md) 的 E5b 节为准。下文 E5a/E5a2 退出段是历史记录，不是 E5b 当前结果。


> 阅读边界：下文保留 E5a 实现前设计，描述目标语义，不是已完成证明。WO-E5a2 中所有者已澄清系统临时目录允许使用，将 E5a 按部分完成提交为 `5b09ea3`；旧报告的“整单作废”不再适用。续作的已验证范围、实测和遗留项以 [E5a2 报告](file:///D:/eab-wt/cx-e2/reports/codex/E5a2_report.md) 为准，未过 G6。

## 目标、范围、验证和回滚
- 目标：对给定有限浮点坐标的有理数值精确分支；浮点仅作构造输出或经证明的过滤候选。
- 仅修改本工作树，不做 Git 写操作。margin/entrance3/interlock/frozen 只允许必要的最小适配，不在此单改变其语义。
- 验证：独立有理数 oracle、三维 G0 零跳样零豁免、过滤对拍、指定源码突变、最终 `PYTHONDONTWRITEBYTECODE=1 python -X utf8 -m pytest -q`、函数行号校正。
- 回滚锚：初始 HEAD `a47933682d9764b15e20d7200a6a37a1e8f14aee`，初始工作树干净；源文件/测试/文档字节备份 `reports/codex/E5a_evidence/tmp/pre_e5a.zip`。不使用 reset/checkout。
- 用户禁止 worktree，不能声称满足新 worktree/G6 退出门；本次全绿不等于 G6 验收。

## 1. 两种几何对象，不暗中凸化凹块
一般 `Polyhedron(verts, faces)` 仍表示输入面环确定的闭合定向表面。非共面多边形按确定性投影耳切三角化成为折面；不能说舍入后的四个点仍然共面。凹多边形不能扇形填充凹口。

显式凸 API（convex_hull_3d、凸对 E、membership_convex3、local_facets3/G0）采用另一明确语义：**凸块等于输入顶点集的精确凸包**，输入面是来源/拓扑提示。舍入形成的微凹被凸包填平，微凸脊保留；不按噪声抹掉。一般相交 API 不能未经声明替换为凸包，尤其 L/U/互锁块绝不自动凸化。

选择凸包而非微凹拒收，是为了使显式凸 E 定理适用于舍入后的工程输入；代价是区分凸模型与给定表面模型。两模型只有在输入表面精确为凸时才能直接当作相同对象。重复点去重，共线边内点/共面面内点不能成为极点；零体积明确拒收。仅精确 orient3d=0 的相邻三角可以合并，不近似合并微二面角。

## 2. 编号与标签
一般表面 API 保持原始 face/edge/vertex 编号。显式凸路径使用缓存的 canonical convex view：尽量保留来源顶点编号；原面确实等于精确 supporting facet 时保留其编号，其他 facet 确定性排序，并记录输入面包含关系。非共面四边形可能对应多片 facet，也可能出现不属于任何输入面的新 facet，不能把整个四边形冒充一个平面。

凸路径 VF/FV/EE/VE3/EV3/VV3 标签属于同一 canonical view；解释标签的函数必须先解析同一 view。不能把 canonical face 下标直接用于原始 faces。一般单盖 API 按原始表面编号。跨模型比对使用精确支撑顶点集，不按近似法向配对。

## 3. 精确 E、局部规则及 G0 三票
凸 E = conv{b−a}。必须先有理化坐标再相减，不能将已舍入 sub(b,a) 当原问题的精确差点。支撑面用未归一化有理叉积；F_A=argmin n·a，F_B=argmax n·b。仿射维数精确，严格 facet 恰为维数组合 (0,2)、(2,0)、(1,1)；其他二维支撑和是退化 facet，不是 ambiguous。

局部命题4/5用原坐标派生未归一化棱/面法向，精确棱弧、顶点锥及锥的相对内部相交；不能把浮点单位方向再有理化冒充原始法锥。

G0 票一：独立有理数 SAT/表面相交对被测成员。平移也在有理数中相加，防止两票比较不同舍入对象。随机样本之外强制 E 顶点、每条棱有理中点、每个精确 facet 有理重心；内/外/边界全部计分。票二：独立差点凸包支撑集合与局部标签双向全量比较，漏/多一个都失败。票三：完整精确极点集等于局部锥交集，没有 ambiguous/low/low_e/高度豁免。oracle 不借用被测法向/棱弧/锥交原语；共用原始坐标和 Fraction 不算共用几何原语。

## 4. 一般三角化表面的成员与相交
点在三角形、线段−三角形、三角形−三角形用有理符号和闭区间。成员先查精确表面，再用精确射线奇偶；射线遇边/顶点退化换确定性整数方向，不能重试耗尽默认边界。

相交三态为分离 −1、仅边界相触 0、内部相交 1。必须覆盖没有顶点在对方内部的穿透及共面重叠，不能仅靠顶点包含或随机微推。凸表面可用精确 SAT；一般表面需要三角相交和局部体侧/内部见证。一般路径未完整验证时如实标未完成，不以改名宣称精确。

## 5. 域窗口与噪声带
调用方明确给出的搜索 window、贴合距离、角域扩张保留，只能增加候选，不能改变 strict/凸性/共面/零非零。兼容 tol>0 成员报告带必须有真实距离见证并与精确分类分离；tol=0 不加 noise_floor。

删除：凸包可见性/细条删除/极点吸收的噪声阈值、近似共面合并、G0 支撑带/ambiguous/low_e、锥交绝对重心阈值、近平行线独立浮点参数分支。noise_floor/face_noise 仅作可分辨性或构造误差报告，不作本单精确答案裁决。

## 6. 保守过滤与性能
orient3d 用浮点 determinant 和严格误差上界；只有 |det|>bound 才采纳符号，否则 Fraction。界覆盖相减/乘加误差及次正规/下溢绝对传播项，非有限中间值退路。Fraction 输入不得被 float 替代；允许保留原值并在过滤界内额外计入有理数到浮点转换误差，未证实则仍算原值。二维热点仅在不改精确构造和返回契约处加过滤/确定性缓存；LP 保留精确证书。

逐个对拍随机、共面、近平面、工程坐标、指数跨度、次正规。过滤界缩小10倍用真实错号见证击中，未找到就如实列未完成，不能伪造返回值。E5a2 全套目标 <=900 秒（理想 <=600 秒），交付实测而非预估。

## 7. 测试迁移与分阶段交付
“舍入四边形仍平面”“小于tol的真实脊可以消失”“所有边界结构计数随浮点旋转不变”等旧口径与新精确输入契约冲突。相同输入每格改用独立精确 oracle 零错，同时保留离边界稳定区不变性；逐条记录旧/新断言与不弱化理由。不删测试、不 skip/xfail。若不能可靠完成全量精确化，保留经验证的全绿子集，报告 PARTIAL，不伪造完成。

## 8. WO-E5a2 已接线范围与仍不可推论的范围

### 一般闭表面

旧 `point_in_polyhedron`、`segment_crosses_face`、`polyhedra_overlap` 已调用有理表面路径。契约前提为有效、定向朝外、闭合、嵌入的有界表面；不声称自动修复自交、非流形或反向输入。凸 SAT 快路先证明输入每个三角平面对全部原顶点均为支撑平面，不能用凸包替换一般实体。

一般内部重叠：用对方所有三角平面分割每个三角面；共面时还按对方三角边直线分割。每个开二维单元内对方成员状态不变。非空有界三维交集必有一片开边界，或者位于另一实体内部，或者两表面共面且内侧一致。单元有理重心沿内向法线推进，步长是所有平面的首个正截距的一半；再以精确成员核验其同时在两体严格内部，得到证书，而不是随机微推。点成员用精确射线退化换向；线段接口只报告横穿，非共面折棱切向接触不应算穿透。门与内部突变见 `test_e5a2_surface.py` 及本单报告。

点的正 tol 是到三角表面的欧氏报告带；实体相交的正 tol **只在分离侧**报告表面距离带，真实内部重叠始终为 1。旧门中舍入后真实微贯入从“相触”转为内部，原输入/全部网格保留，以独立精确 oracle 迁移；margin 的贯入哨兵因此随之生效，但本单不宣称 margin 其余分支已精确。

### 一般单盖的有限解释（A2 选择允许的边界说明方案）

源面标签的 VF/FV 用 Newell 方向及通过首顶点的锚平面；域判据用主投影绕数；棱/顶点方向由源拓扑产生。对非平面环，这只是描述符：循环移动首顶点可以改变 gap，投影见证可能不在任意源三角面上。两个实值反例门固定此界限（`test_e5a2_covers.py`）；不可称其为三角化折面实体的完整法锥或真实接触见证。canonical convex-view 的标签域独立保留。

### 距离窗口与性能

枚举六类窗口用原坐标的精确平方距离，盖 gap/normal/witness 仍是构造输出。凸 E 正 tol 的内侧最短支撑平面距离等于边界距离；外侧支撑平面距仅是下界，剩余候选由 `conv({b-a-x})` 的精确最小范数点证书裁决。外角例及恢复平面带的真实内部突变有门。

性能优化没有引入新的浮点过滤或缓存层：三维 Fraction 点叉积延迟到最后一次规范化，独立 SAT 与凸成员平面用等价整数行，二维已为 Fraction 的符号用整数分子，EE 参数延后到锥接受之后。既有浮点/Dual 算术次序与独立 oracle 边界不变；逐值对拍、profile、实测和保留的 E5b 工作见 `reports/codex/E5a2_report.md`。本单禁止新 worktree，所有本树回归都不是正式独立六路 G6 退出。

### interlock 接线修正与缓存使用边界

精确实体三态揭示旧逃逸循环不能给同一舍入簇内的不同构造高度复用状态：低一格可能真贯入，高一格已经分离。E5a2 对不同高度分别核验；原候选簇均未通过时，仅在既有法向舍入报告带内构造一次上探，并核验**实际返回高度对应的原对象平移**不再贯入。返回高度是经过精确验收的浮点构造，winner/tied_labels 仍描述 nominal 簇，不声称全链精确首出或折面盖完备。桥接门 `test_e5a2_interlock_bridge.py`；原逃逸、候选和灵敏度门没有删格。

这些调用只消费 `state == 1`，由相交接口正 tol 仅改变分离侧 -1/0 的契约，使用零 tol 与正 tol 的贯入判定严格相同，可省去每次二分的欧氏近带距离。它不同于把微贯入重新吞成相触。

本单扩展既有内容寻址缓存的整数 payload，没有新增缓存层。串用门覆盖内容键及 canonical-self 对象变更；**不覆盖任意源对象原地修改**。交叉审查复现 HEAD 已有 `_convex_view` 对非 canonical 源对象修改后不失效的问题；当前应视输入为不变，修改后重建对象。修复上游缓存失效契约留给后续，不以本单对拍掩盖此限制。


## WO-E5a2 退出状态：PARTIAL（2026-10-12）

本单指定底层门与整数化对拍通过，但完整测试未全绿，不构成里程碑退出。严格表面语义揭示旧 interlock 近竖直事件被噪声政策丢弃：原80个竖墙输入中7格存在独立认证的更低分离高度，当前返回约1.2不是最小逃逸。不能把原最小逃逸门改成只检查安全上界。另有旧并列窗口突变牙失效；加强草案只在证据中，未应用。完整失败清单、实测耗时、独立反证及 WO-E5b 交接以 `reports/codex/E5a2_report.md` 为准；竖墙证书见 `reports/codex/E5a2_evidence/a1/walls_handoff.md`。没有宣称全套≤900秒、正式G6、新worktree或全链精确化通过。


## E5b：默认精确、显式接触窗口与运动证书（2026-10-12）

### 1. 默认数据与表示

输入 float 是其给定二进制数的精确有理值，不是未舍入的设计几何。有效、朝外、闭合、嵌入的三角表面是一般实体判定域；非共面面环按确定性三角化解释。默认 `contact_window=None`（以及 0）不吞微贯入：`body_distance` 返回 `PENETRATING` 哨兵，`inflated_membership(..., delta=0)` 为 INSIDE；正距离不因旧 ctol 而变零。距离、δ、关注带的判定比较有理平方量，不用浮点 sqrt 决定状态。

门：`test_margin_exact.py` 的默认微贯入、精确边界、非共面三角距离与 underflow closed 状态；`test_margin_resolution.py` 保留原网格，精确模式另对独立四面体并集整数 SAT。`entrance_block_convex` 先将每个原坐标转为有理数再作差，不能先舍入差点；见 `test_kernel3d_geom.py` 与 `test_margin_exact.py`。

### 2. 显式局部贯入厚度窗口的数学定义与限度（E5 已完成）

`contact_resolution(A,B)` 只提供旧口径数值 `max(effective_geom_tol, 1e-12*max(diag)) + rounding_floor`，调用方必须显式传入 `contact_window=w`。w 有限且非负。分离侧精确表面距离平方 ≤ w² 时按相触报告（距离 0、ON_BOUNDARY、闭合）。贯入侧采用所有者批准的**局部贯入厚度窗口**：六轴刚性平移后的内部不交充分证书 OR 局部径向薄壳证书。`contact_window` 名称保留兼容，未新增参数或别名；该量不是整体最短分离平移的欧氏贯入深度 PD，也不是其完整子水平集：

1. 原实体对；
2. A 沿每个坐标轴精确平移 +w 或 −w 后的六个实体对：任一内部不交证明存在长度 w 的非贯入位移，不保证闭集完全分离；
3. A 或 B 各自可认证的星核收缩模型。中心 c 取原顶点精确平均；必须对每个朝外三角面有 `n·(c−p)<0`。令 `R=max_v ||v−c||_1`，`α=min(w/R,1/2)`，内核顶点为 `c+(1−α)(v−c)`。每条被移除的径向壳段长度 ≤ αR ≤ w。内核与另一实体不贯入即证明重叠只在厚度至多 w 的该表面壳内。无星核证书时不启用该项。

`exact_sweep.contact_models` 唯一生成此集合；margin 对集合作精确 OR，interlock 对同一集合的最早根取最小。证书失败只表示未被该窗口接受，**不能声称真欧氏穿透深度 > w**。六方向证书是坐标系相关的有限政策，不宣称它等于旋转不变的完整欧氏偏置；星核壳证书也不等于最短刚体脱离。双侧微量夹持可能需要很大的整块脱离，却仍属于薄局部接触壳；这正是原抖动墙窗口可以回到名义高度的区别。严格物理默认路径不采用任何此政策。

独立门：原 margin touch/subtol 逐格整数 SAT；墙的独立扫掠 SAT、严格分离轴和自有射线包含排除；`test_interlock_exact.py` 的三尺度/大平移盒对窗口根闭式值与 margin 相触、根前 INSIDE 的一致检查。所有旧不变性断言留在调用方显式窗口下，另保留默认精确 oracle。并未宣称对任意凹体提供完整欧氏穿透深度算法。

### 2a. 可靠性、限制与独立门（WO-PERF 定稿）

**正本口径（R7FIX）**：只读正本 01 第 5 行限定紧凸块，第 34 行定义 `PD_closed = inf{||d||₂ : (A+d)∩B=∅}`。这是闭集完全分离的**下确界**，相触处通常并不取到。当前一般闭表面窗口只提供 `rho = inf{||d||₂ : int(A+d)∩int(B)=∅}` 的有限六轴充分证书；一般非凸体可能 `rho < PD_closed`，不能把内部不交或一个贴合姿态视为 E 的外边界。对凸实体，支撑平面可在任意小的进一步平移后严格分离，二者下确界相同；原凸盒门只覆盖这个特例。

**封闭空腔反例**：A 是中心 `(-1/8,0,0)`、半边长 `1/2` 的闭立方体；B 是半边长 2 的闭外立方体减去半边长 `1/2` 的开内立方体。`+1/8 e_x` 后 A 恰好贴合空腔，内部不交，故 `rho=1/8`；相同尺寸不可能严格装进开腔，A 要与闭壳完全相离必须移出外盒，`PD_closed=19/8`，且该值处仍相触，只能作为下确界。默认精确路径仍报贯入，显式 `w=1/8` 仍按既定政策报相触。门：`tests/test_r7fix_docs.py::test_g6g09_tight_closed_cavity_distinguishes_rho_from_pd_closed`。不改薄壳或六轴运行政策，不改只读正本。

“相触”的可靠性是带分支的精确析取，不能把两分支混为 PD 证书：

- 六轴分支：存在 `d ∈ {±w e_x, ±w e_y, ±w e_z}`，`int(A+d) ∩ int(B)=∅`，因而 `rho ≤ ||d||₂ = w`，不能据此推出 `PD_closed ≤ w`。对原本分离输入另由真实距离平方 `d² ≤ w²` 接受；这不是贯入分支的结论。
- 薄壳分支：存在经认证的 A 或 B 星核 K，`int(K) ∩ int(other)=∅`；原实体每处严格重叠都在该体的闭径向壳内，任意径向壳段欧氏长度至多 `αR ≤ w`。这不意味着有同一个短平移能同时解除每处接触。
- 反向不成立：报 `PENETRATING` 只意味着有限证书未通过，**不推出 PD > w**；默认 `None/0` 则仍是原实体严格精确三态，不走窗口。

独立门均在 `tests/test_perf_contact_window.py`。oracle 只用 Fraction 标量、预先给定的精确正交基、区间积、笛卡尔积及平方范数；不调用被测侧法向、SAT、点成员、星核、距离或三角化原语。每个参与区间判定的实体先证明其八个顶点恰好是区间积的全部角点，防止把 AABB 当真实实体。

| 声称 / 不保证项 | 具体位形及独立判据 | 命名门 |
| --- | --- | --- |
| 六轴成功 ⇒ rho ≤ w；凸盒特例另有 PD_closed = rho = w，六个方向都保留 | 两等大盒重叠恰好 w，仅一个指定符号轴能分开；18 格含三尺度、非对称平移与工程坐标 1e6；直接测位移平方 = w²，并用盒构型差的最近面算 PD_closed（下确界，不是闭集相离位移的最小值） | `test_each_of_six_axis_certificates_proves_pd_at_most_window` |
| 薄壳成功 ⇒ 每处重叠在 ≤w 径向壳内，但不保证 PD≤w | 半长 `(1,1/16,1/16)` 的键被双壁夹持，w=1/64，两侧重叠 3w/4；独立区间证明两重叠区均避开内核，逐顶点同胚比例和凸范数最大值证明全部径向壳段≤w；禁入平移盒的并覆盖 `[-1,1]^3`，故 PD>1 | `test_shell_certificate_contains_every_overlap_region_but_does_not_bound_pd` |
| 六轴坐标依赖；斜向短脱离可能漏 | 半长 `(1,4,4)` 盒沿法向重叠 9/40，w=1/4；绕 z 作有理正交旋转 `(cos,sin)=(3/5,4/5)` 后六轴与双内核全贯入，但独立斜向平移长度 PD=9/40<w 即可接触分离 | `test_shorter_oblique_escape_can_be_missed_so_penetrating_does_not_mean_pd_exceeds_w`；`test_six_axis_coordinate_dependence_means_rotation_invariance_is_not_guaranteed` |
| 旋转不变性连薄壳分支也未保证 | 前述双壁键作同一精确旋转；两姿态都不存在轴向短脱离，未旋转只有 core_A 证书通过，旋转后 L1 半径上界变大而全部失败；几何 PD 本身未改变 | `test_local_shell_rotation_invariance_is_not_guaranteed_either` |
| 门穿过真实窗口路径 | `star_core` 内 α 的 w 改 2w：两侧 3w/2 真实厚重叠被错误接纳，公开 membership 断言 `reject-thicker-than-w-shell` 报红；`contact_models` 内删 +z：+z 唯一证书格公开 membership 的 `axis-public-report` 报红 | `test_shell_window_doubling_mutation_is_caught_by_public_rejection`；`test_five_axis_mutation_is_caught_by_the_missing_direction_gate` |

上述限制是明示的窗口定义，不修改默认精确路径的刚体/单位不变性契约。窗口参数是局部接触建模政策，不应写成“有保证的 PD 求解器”；DDA 式各接触分别贯入的解释由所有者批准，未据此声称工程标定或姊妹求解器已部署。

### 3. 最早逃逸根与首入

`surface_events` 枚举真实三角表面的 VF/FV/EE（含三角对角边）事件，平行共面持续情形补端点过边/重合事件。仅精确零才平行，近竖直特征不得按噪声删除。所有根是有理数；相邻根之间拓扑不变。在正根处逐个精确判非贯入，首个通过者的每个此前开区间取有理中点，全部须严格贯入；否则响亮失败。`EscapeSolution.exact_height / exact_offset` 是权威运动数据，`interval_certificate` 为胜出模型的逐区间证明，`nonpenetrating_state` 是该模型根处检查。窗口中其他模型在当前上界前逐事件检查以排除更早根；返回的单份区间证书不冒充全部模型的证明清单，可按 `contact_models` 重算。

`height` 为向上舍入的 binary64 **显示值**，不是将每个顶点重新做浮点加法后的安全保证。后者是另一组数据，须重新精确判定。`cover_label/tied_labels` 保留名义浮点报告簇以兼容旧微分实验；真正事件读 `exact_contact_label/normal`。窗口 winner 为 core/shift 时，事件特征属于对应证书模型，不能直接解释成原实体的物理活动接触。非 Dual 冻结高度用原始有理未归一化平面比值，避免近竖直分母放大单位法向舍入。Dual 片内计算仍保留所有导数通道。

`escape_height_brute` 现在保留 bracket 签名但也走完整事件分区，**不再是独立 oracle**：非凸非单调路径不能用二分跳过更早分离区间。独立性由测试专用扫掠 SAT/oracle 提供。

首入的根、时刻比较、并列、t_max、深度平方均精确；t* 前自检使用完整事件前一区间的有理中点。非共面面的 `surface_label/surface_members` 保存三角限定，冻结应消费该视图；FF/FE 合并标签本身不由 frozen_normal 接受，须从 surface_members 选择原始 VF/FV/EE 成员；兼容 `label/members` 不是折面上的精确平面。`merge_degenerate` 只合并精确共面簇，微台阶门及恢复容差突变固定此边界。局部 `shortest_exit3` 不冒充任意凹体全局最短出口。

### 4. 缓存与等价优化

Polyhedron 保留可变外层 API；全部缓存按顶点与面内容签名失效，原地替换后不得复用旧凸视图。元门 `test_e5b_polyhedron_cache.py` 包含内部门缺失顶点签名突变。缓存不依赖对象 id。

精确布尔三角相交以平面切段/二维 SAT 取代构造交点集合；横截严格内部正证书仅提前返回经两原表面精确点包含复核的贯入，其余走完整 arrangement；已认证星核表面的四面体并集使用整数 SAT；点包含射线以清分母整数线性式替代 Fraction 交点构造。正窗口三角距离另加精确支撑平面距离下界：仅 `gap² > w²*n²` 才拒绝，等号仍进入闭窗口；`test_e5b_triangle_near.py` 同时逐值对拍旧全特征路径、独立闭式阈值，并用 `>` 改 `>=` 的内部突变钉住等号。没有浮点否决过滤。逐值旧路径对拍与不共用原语 oracle 见 `test_e5b_triangle_boolean.py`、`test_e5b_transverse_certificate.py`、`test_e5b_surface_integer.py`。margin/事件内容缓存有 cache-versus-uncached 输出对拍。

### 5. DDA / TIA 适配边界

适配器必须显式选择：(a) 默认精确按传入数据回报微贯入，或 (b) 将其物理/离散化接触厚度作为 `contact_window` 传入。库不能暗猜 ctol；不得把窗口相触当作原实体严格不贯入证明。保留源坐标、运动有理根与证书，显示/导出若必须舍入则对舍入后的实际数据重新判定；冻结使用精确 surface 特征而非非共面源环的拟合平面。姊妹三线本单只读，**未改适配器、未部署开关、未进行求解器标定/工程验证**。

本单完整测试、耗时、逐条处置与突变目标断言见 `reports/codex/E5b_report.md`。本树开发验证和同组交叉审查不替代独立六路 G6；按工单禁令未创建新 worktree。

## R6FIX 契约补充（第六轮修复，待独立复核）

- **缓存不是共享可变结果**：内容签名覆盖源顶点和面；canonical view 的缓存保存不可变内容，非自视图每次返回隔离对象；拓扑列表和 margin 内部视图/盖记录不能经返回别名污染后续答案。既有源内容失效门继续保留。门：`tests/test_r6fix_geom3.py`、`tests/test_e5b_polyhedron_cache.py`、`tests/test_r6fix_construction.py::test_margin_internal_cached_views_are_isolated` / `test_margin_internal_cached_records_are_isolated`。
- **面提示不是凸体定义**：显式凸 API 只依赖 `conv(vertices)`；只有面环符合 canonical 朝外支撑环时才允许保留编号捷径。`is_convex/reflex_edges` 用精确未归一化符号，不再用 dihedral_noise 吞掉微凹。门：`tests/test_r6fix_geom3.py`。
- **严格样本必须真正被检验**：非凸 G0 的分类、距离和首出口 oracle 独立于被测生产几何原语；原来 `1e-12*L` 预筛删除。二维/三维微间隙和二维微贯入均计入实测样本，法锥内部变异使盖集丢失时不能通过。门：`tests/test_r6fix_g0.py`。一般任意表面仍须符合各 oracle 声明的有效输入前提，不把有限测试外推成穷举证明。
- **构造的相对量先精确后舍入**：`nearest_point_on_convex_entrance(..., exact=True)` 输出有理数投影见证；默认全局浮点点仅是显示，可能与查询点舍入相同。距离/法向从精确相对向量构造，不能反减显示点。门：`test_g6f08_distance_and_normal_use_exact_relative_projection`、`test_projection_exposes_exact_witness_beyond_global_float_resolution`、`test_exact_relative_projection_covariance_on_nonaxis_corner`（均在 `tests/test_r6fix_construction.py`）。
- **输出可表达性与状态分开**：`eab.construction.sqrt_rational` 先拆指数给候选，再用精确相邻中点正确舍入；默认在非零结果下溢/溢出时响亮失败。允许显示下溢的内部流程必须显式传 `allow_underflow=True`；`MarginContact.exact_distance_squared` 保留非零精确证据，`closed` 仍精确。门：`test_rational_sqrt_rounds_only_the_final_root` 和 `tests/test_margin_exact.py::test_closed_is_exact_when_the_display_gap_underflows_to_zero`。
- nominal 非 Dual 平移保留输入有理仿射值，不能因 `0` / `0.0` 等值偏移改变是否可构造。门：`tests/test_r6fix_geom3.py`。一般 surface 与显式凸模型仍是不同契约，不暗中凸化。

- **盖的显示证书**：`Cover3.exact_gap_squared/exact_gap_sign` 与 VF/FV 的 `exact_area_squared` 保留舍入前的幅值与符号。六类盖从有理相对量作最终开方，非零小量显示为 0 时仍有公开证书；窗口继续读取原数据而非显示 gap。门：`tests/test_r6fix_construction.py::test_cover_construction_exposes_exact_nonzero_gap_and_area`、`tests/test_e5a2_covers.py::test_enumeration_window_does_not_read_a_gap_rounded_to_zero`。

外部正本 `D:/E(A, B)` 按本工单只读；此节是仓内设计同步，不声称已改外部设计正本。
