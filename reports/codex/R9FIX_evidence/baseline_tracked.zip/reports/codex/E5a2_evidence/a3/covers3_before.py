"""Three-dimensional contact covers with exact coordinate predicates.

For convex APIs the body is its exact vertex-set convex hull; labels index the
canonical views returned by geom3.exact_convex_view. General single-cover and
enumeration APIs retain the supplied surface topology. On exactly planar faces
all local cone, strictness and extent branches are rational; nonplanar general
surface facets are not silently convexified (the remaining surface migration is
tracked in the WO-E5a report).

Original floating coordinates denote exact rational data. Derived unnormalised
normals, incident vectors, projections and parameters stay rational until the
construction output. A strict or zero-dimensional decision never uses a noise
floor. Positive caller tol / extent_tol may only expand closed domain windows;
strictness always reads the exact zero threshold. window is a caller distance
search window. Construction outputs (unit normals, points and gaps) are floats.

Gordan cone feasibility is certified with an exact minimum-norm active-simplex
algorithm; no thin triangle/simplex or barycentric tolerance changes the answer.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
from itertools import combinations

from . import geom3
from .geom3 import (Polyhedron, Vec3, add, cross, dot, mul, neg, norm,
                    sub, unit)


def _qvector(v):
    """Preserve the exact value of each supplied coordinate (including Fraction)."""
    return _qvector_cached(tuple(v))


@lru_cache(maxsize=8192)
def _qvector_cached(v):
    return tuple(Fraction(c) for c in v)


def _qedge(P, e):
    direction = _qedge_vector_cached(tuple(P.verts[e[0]]), tuple(P.verts[e[1]]), _qvector)
    if not any(direction):
        raise ValueError(f"zero-length edge {e} (consecutive duplicate vertex)")
    return direction


@lru_cache(maxsize=8192)
def _qedge_vector_cached(a, b, vector_implementation):
    return sub(vector_implementation(b), vector_implementation(a))


def _qnormal(P, fi):
    f = P.faces[fi]
    return _qnormal_cached(tuple(P.verts[i] for i in f))


@lru_cache(maxsize=4096)
def _qnormal_cached(points):
    o = _qvector(points[0])
    n = (Fraction(0),) * 3
    for a, b in zip(points, points[1:] + points[:1]):
        n = add(n, cross(sub(_qvector(a), o), sub(_qvector(b), o)))
    return n


def _qincident(P, vi):
    return _qincident_cached(tuple(P.verts), tuple(P.faces), vi, _qedge)


@lru_cache(maxsize=8192)
def _qincident_cached(vertices, faces, vi, edge_implementation):
    P = Polyhedron(list(vertices), list(faces))
    return tuple(edge_implementation(P, (vi, e[1] if e[0] == vi else e[0]))
                 for e in P.edges() if vi in e)


def _float_vector(v):
    return tuple(float(x) for x in v)


def _qunit(v):
    """Construction only: scale first to avoid under/overflow."""
    scale = max(abs(x) for x in v)
    if not scale:
        raise ZeroDivisionError("unit of zero vector")
    return unit(tuple(float(x / scale) for x in v))


def _outside_dot_band(value, a, b, tol):
    """Exact comparison with an explicit dimensionless normalized-dot window."""
    return value > 0 and (tol <= 0 or value * value > _squared_tol(tol) * _qnorm2(a, dot) * _qnorm2(b, dot))


@lru_cache(maxsize=64)
def _squared_tol(tol):
    return Fraction(tol) ** 2


@lru_cache(maxsize=16384)
def _qnorm2(v, dot_implementation):
    return dot_implementation(v, v)


@lru_cache(maxsize=8192)
def _normalised_constraint(v):
    return mul(v, 1 / max(abs(x) for x in v))


def _qvertex_contains(P, vi, d, tol=0.0):
    edges = _qincident(P, vi)
    return _qvertex_state_cached(edges, tuple(d), tol, _outside_dot_band)


@lru_cache(maxsize=16384)
def _qvertex_state_cached(edges, d, tol, band_implementation):
    if not edges:
        return -1
    strict = True
    for e in edges:
        value = dot(d, e)
        if band_implementation(value, d, e, tol):
            return -1
        if value >= 0:
            strict = False
    return 1 if strict else 0


def _qedge_contains(P, e, d, tol=0.0):
    """Exact oriented wedge, no atan2, normalized vectors, or noise bands."""
    trav = P.edge_traversals(e)
    if len(trav) != 2:
        return -1
    (f1, a, b), (f2, _, _) = trav
    t = _qedge(P, (a, b))
    n1, n2 = _qnormal(P, f1), _qnormal(P, f2)
    convex, h1, h2 = _qedge_frame_cached(t, n1, n2, cross, dot)
    if not convex:
        return -1
    if _outside_dot_band(abs(dot(d, t)), d, t, tol):
        return -1
    # The inward normals to the two sides of the arc. Both are exact.
    s1, s2 = dot(h1, d), dot(h2, d)
    if _outside_dot_band(-s1, h1, d, tol) or _outside_dot_band(-s2, h2, d, tol):
        return -1
    return 1 if s1 > 0 and s2 > 0 and dot(d, t) == 0 else 0


@lru_cache(maxsize=8192)
def _qedge_frame_cached(t, n1, n2, cross_implementation, dot_implementation):
    """Cache only edge-invariant exact wedge data; predicates are unchanged."""
    return (dot_implementation(cross_implementation(n1, n2), t) > 0,
            cross_implementation(t, n1), cross_implementation(n2, t))


def _clamp01(s: float) -> float:
    # Integer endpoints preserve Fraction arithmetic for exact projections.
    return 0 if s < 0 else (1 if s > 1 else s)


def _closest_on_face_boundary(x: Vec3, P: Polyhedron, fi: int) -> Vec3:
    """面 fi 的边界折线上离 x 最近的点（x 已在面平面上、落在多边形外或边上时，它就是面多边形上的最近点）。"""
    f = P.faces[fi]
    best, bd = f and P.verts[f[0]], float("inf")
    for i in range(len(f)):
        a, b = _qvector(P.verts[f[i]]), _qvector(P.verts[f[(i + 1) % len(f)]])
        d = sub(b, a)
        dd = dot(d, d)
        q = a if dd <= 0.0 else add(a, mul(d, _clamp01(dot(sub(x, a), d) / dd)))
        w = sub(x, q)
        if dot(w, w) < bd:
            best, bd = q, dot(w, w)
    return best


def _face_witness(x: Vec3, g: float, P: Polyhedron, fi: int, lng: float) -> tuple[Vec3, bool]:
    """Exact projection extent; an explicit length window only expands acceptance."""
    locate = geom3.face_polygon_locate
    if locate(x, P, fi, max(0.0, lng)) < 0:
        return _float_vector(x), False
    witness = x if locate(x, P, fi, 0.0) >= 0 else _closest_on_face_boundary(x, P, fi)
    return _float_vector(witness), True


def _orth(v: Vec3, t: Vec3) -> Vec3:
    """v 去掉沿单位向量 t 的分量后单位化——**按构造正交**（做两遍，余量到 eps 量级）。"""
    v = sub(v, mul(t, dot(v, t)))
    v = sub(v, mul(t, dot(v, t)))
    return unit(v)


@dataclass(slots=True)
class Cover3:
    kind: str                     # VF | FV | EE | VE3 | EV3 | VV3 | FF | FE | EEP
    a_feature: tuple[str, ...]    # ("vertex", i) | ("face", i) | ("edge", i, j)
    b_feature: tuple[str, ...]
    normal: Vec3 | None           # B → A 的分离方向（单位）
    gap: float                    # 沿 normal 的有符号间隙（>0 分离）
    point_a: Vec3 | None          # A 侧代表点
    point_b: Vec3 | None          # B 侧代表点
    params: tuple[float, ...]     # VF/FV: 面内重心参数留空；EE: (s, t) 两棱参数
    area: float | None            # 代表面积（VF/FV 取面面积；EE 为 None）
    strict: bool                  # 法锥相对内部条件严格成立
    in_extent: bool               # 投影/最近点落在面内或段内

    def label(self) -> tuple:
        return (self.kind, self.a_feature, self.b_feature)


# ------------------------------------------------------------------ 法锥判据

def vertex_cone_contains(P: Polyhedron, vi: int, d: Vec3, tol: float = 0.0) -> int:
    """Exact local vertex cone: 1 strict / 0 boundary / -1 outside.

    The supplied direction and original vertex coordinates are exact inputs.
    Positive tol only expands the closed cone; it never changes strictness.
    """
    return _qvertex_contains(P, vi, _qvector(d), tol)


def edge_arc_contains(P: Polyhedron, e: tuple[int, int], d: Vec3, tol: float = 0.0) -> int:
    """Exact local convex edge arc, with an optional explicit angular window."""
    return _qedge_contains(P, e, _qvector(d), tol)


def cone_constraints(A: Polyhedron, ia: int, B: Polyhedron, ib: int) -> list[Vec3]:
    """Unnormalized exact incident vectors defining N_B(b) intersect -N_A(a)."""
    return [*_qincident(B, ib), *(neg(f) for f in _qincident(A, ia))]


def _closest_point_on_segment(a: Vec3, b: Vec3) -> Vec3:
    return _float_vector(_qclosest_segment(_qvector(a), _qvector(b)))


def _qclosest_segment(a, b):
    d = sub(b, a)
    dd = dot(d, d)
    if not dd:
        return a
    t = max(Fraction(0), min(Fraction(1), -dot(a, d) / dd))
    return add(a, mul(d, t))


def _qclosest_triangle(a, b, c):
    n = cross(sub(b, a), sub(c, a))
    nn = dot(n, n)
    if nn:
        p = mul(n, dot(a, n) / nn)
        if all(dot(cross(sub(u, p), sub(v, p)), n) >= 0
               for u, v in ((b, c), (c, a), (a, b))):
            return p
    candidates = [_qclosest_segment(a, b), _qclosest_segment(b, c), _qclosest_segment(c, a)]
    return min(candidates, key=lambda x: dot(x, x))


def _closest_point_on_triangle(a: Vec3, b: Vec3, c: Vec3) -> Vec3:
    return _float_vector(_qclosest_triangle(*map(_qvector, (a, b, c))))


def _qtetra_contains_origin(a, b, c, d):
    def volume(p, q, r, s):
        return dot(sub(q, p), cross(sub(r, p), sub(s, p)))
    v = volume(a, b, c, d)
    if not v:
        return False
    zero = (Fraction(0),) * 3
    numerators = (volume(zero, b, c, d), volume(a, zero, c, d),
                  volume(a, b, zero, d), volume(a, b, c, zero))
    return all(x * v >= 0 for x in numerators)


def _qclosest_simplex(points):
    """Nearest simplex point and its smallest positive-dimensional support."""
    best = min(points, key=lambda x: dot(x, x))
    support = (best,)
    best2 = dot(best, best)
    for subset in combinations(points, 2):
        p = _qclosest_segment(*subset)
        d2 = dot(p, p)
        if d2 < best2:
            best, best2, support = p, d2, subset
    for subset in combinations(points, 3):
        p = _qclosest_triangle(*subset)
        d2 = dot(p, p)
        if d2 < best2:
            best, best2, support = p, d2, subset
    for subset in combinations(points, 4):
        if _qtetra_contains_origin(*subset):
            return (Fraction(0),) * 3, subset
    return best, support


@lru_cache(maxsize=2048)
def _qclosest_hull(pts):
    """Exact fully-corrective minimum-norm algorithm (simplex size <= 4).

    The support point minimizes the exact linear functional. A nonoptimal
    iterate strictly decreases its rational squared norm, and the projection
    always belongs to one of finitely many simplices. Thus there is no tolerance
    or iteration cap. KKT is checked against every original point before return.
    """
    if not pts:
        raise ValueError("empty point set")
    point = min(pts, key=lambda x: dot(x, x))
    support = (point,)
    while True:
        q = min(pts, key=lambda x: dot(x, point))
        if dot(q, point) >= dot(point, point):
            return point
        previous = dot(point, point)
        point, support = _qclosest_simplex((*support, q))
        if dot(point, point) >= previous:
            raise ArithmeticError("exact minimum-norm iteration did not decrease")


def closest_point_of_convex_hull_to_origin(pts: list[Vec3]) -> Vec3:
    """Nearest point construction, with exact simplex/degeneracy predicates.

    The internal zero predicate is exact; this public vector is a floating
    construction and may round below the representable range. The cone decision
    reads the rational result, never this rounded construction. There is no
    thickness or barycentric tolerance, including for thin simplices.
    """
    return _float_vector(_qclosest_hull(tuple(map(_qvector, pts))))


def cone_relint_direction(g: list[Vec3], tol: float = 1e-12) -> Vec3 | None:
    """Construct a strict cone direction. tol is compatibility-only, not a cutoff."""
    points = tuple(_qvector(x) for x in g)
    if not points:
        return None
    p = _qclosest_hull(points)
    return _qunit(neg(p)) if any(p) else None


def cone_intersection_margin(A: Polyhedron, ia: int, B: Polyhedron, ib: int) -> tuple[float, float]:
    """Distance to an exact positively-rescaled constraint hull; noise is report-only."""
    g = cone_constraints(A, ia, B, ib)
    # Rational normalization preserves whether zero is in the convex hull.
    points = tuple(_normalised_constraint(x) for x in g if any(x))
    noise = max((nz for _, nz in A.vertex_edges(ia) + B.vertex_edges(ib)), default=0.0)
    if not points:
        return 0.0, noise
    p = _qclosest_hull(points)
    return norm(_float_vector(p)), noise


def cones_intersect_relint(A: Polyhedron, ia: int, B: Polyhedron, ib: int, tol: float = 1e-12) -> bool:
    """Exact Gordan alternative: zero outside the constraint hull iff strict feasible.

    tol is retained for call compatibility but cannot discard a thin true cone.
    """
    return _cone_relint_cached(tuple(A.verts), tuple(A.faces), ia,
                              tuple(B.verts), tuple(B.faces), ib,
                              (cone_constraints, _qincident, _qedge, _qclosest_hull,
                               _qclosest_simplex, _qtetra_contains_origin, _normalised_constraint))


@lru_cache(maxsize=8192)
def _cone_relint_cached(av, af, ia, bv, bf, ib, implementations):
    A, B = Polyhedron(list(av), list(af)), Polyhedron(list(bv), list(bf))
    g = cone_constraints(A, ia, B, ib)
    if not g:
        return False
    points = tuple(_normalised_constraint(x) for x in g if any(x))
    return bool(points) and any(_qclosest_hull(points))


def _project_on_face(p: Vec3, P: Polyhedron, fi: int) -> tuple[Vec3, float]:
    n = _qnormal(P, fi)
    point, origin = _qvector(p), _qvector(P.verts[P.faces[fi][0]])
    h = dot(n, sub(point, origin)) / dot(n, n)
    projection = sub(point, mul(n, h))
    gap = dot(_qunit(n), _float_vector(sub(point, origin)))
    return projection, gap


# Facet constructions below use original rational coordinates for every branch.


def vf_cover(A: Polyhedron, ia: int, B: Polyhedron, fb: int, tol: float = 0.0, extent_tol: float = 0.0) -> Cover3 | None:
    """Vertex/face cover with exact local cone and exact projected extent."""
    n = _qnormal(B, fb)
    side = _qvertex_contains(A, ia, neg(n), tol)
    if side < 0:
        return None
    a = A.verts[ia]
    proj, g = _project_on_face(a, B, fb)
    wit, inside = _face_witness(proj, g, B, fb, extent_tol)
    return Cover3("VF", ("vertex", ia), ("face", fb), _qunit(n), g, a, wit, (), B.face_area(fb), side == 1, inside)


def fv_cover(A: Polyhedron, fa: int, B: Polyhedron, ib: int, tol: float = 0.0, extent_tol: float = 0.0) -> Cover3 | None:
    """Face/vertex cover with exact local cone and exact projected extent."""
    n = _qnormal(A, fa)
    side = _qvertex_contains(B, ib, neg(n), tol)
    if side < 0:
        return None
    b = B.verts[ib]
    proj, g = _project_on_face(b, A, fa)
    wit, inside = _face_witness(proj, g, A, fa, extent_tol)
    return Cover3("FV", ("face", fa), ("vertex", ib), neg(_qunit(n)), g, wit, b, (), A.face_area(fa), side == 1, inside)


def _qclosest_params(p1, d1, p2, d2):
    n = cross(d1, d2)
    nn = dot(n, n)
    if not nn:
        return None
    w = sub(p2, p1)
    return dot(cross(w, d2), n) / nn, dot(cross(w, d1), n) / nn


def _closest_params(p1: Vec3, d1: Vec3, p2: Vec3, d2: Vec3) -> tuple[float, float] | None:
    """Exact parallel decision and rational line parameters, float output only."""
    result = _qclosest_params(*map(_qvector, (p1, d1, p2, d2)))
    return None if result is None else tuple(float(x) for x in result)


def _qparameter_in_extent(s, d, extent_tol):
    if 0 <= s <= 1:
        return True
    if extent_tol <= 0:
        return False
    over = -s if s < 0 else s - 1
    return over * over * dot(d, d) <= Fraction(extent_tol) ** 2


def _qclamp(s):
    return max(Fraction(0), min(Fraction(1), s))


def ee_cover(A: Polyhedron, ea: tuple[int, int], B: Polyhedron, eb: tuple[int, int],
             tol: float = 0.0, extent_tol: float = 0.0) -> Cover3 | None:
    """Edge/edge cover: exact arc signs, parallelism, parameters and extent."""
    pa0, pb0 = _qvector(A.verts[ea[0]]), _qvector(B.verts[eb[0]])
    dA, dB = _qedge(A, ea), _qedge(B, eb)
    normal = cross(dB, dA)
    if not any(normal):
        return None
    params = _qclosest_params(pa0, dA, pb0, dB)
    if params is None:
        return None
    s, t = params
    for candidate in (normal, neg(normal)):
        sb = _qedge_contains(B, eb, candidate, tol)
        sa = _qedge_contains(A, ea, neg(candidate), tol)
        if sb < 0 or sa < 0:
            continue
        # All classifications use the rational parameters. Output points are
        # consistently constructed from one exact witness pair, then rounded.
        qa, qb = add(pa0, mul(dA, s)), add(pb0, mul(dB, t))
        unit_normal = _qunit(candidate)
        gap = dot(unit_normal, _float_vector(sub(qa, qb)))
        inside = (_qparameter_in_extent(s, dA, extent_tol)
                  and _qparameter_in_extent(t, dB, extent_tol))
        if not 0 <= s <= 1:
            qa = add(pa0, mul(dA, _qclamp(s)))
            qb = add(pb0, mul(dB, _qclamp(dot(sub(qa, pb0), dB) / dot(dB, dB))))
        elif not 0 <= t <= 1:
            qb = add(pb0, mul(dB, _qclamp(t)))
            qa = add(pa0, mul(dA, _qclamp(dot(sub(qb, pa0), dA) / dot(dA, dA))))
        return Cover3("EE", ("edge", *ea), ("edge", *eb), unit_normal, gap,
                      _float_vector(qa), _float_vector(qb), (float(s), float(t)), None,
                      sb == 1 and sa == 1, inside)
    return None


# Low-dimensional covers retain boundary states; strict is never a filter.


def ve3_cover(A: Polyhedron, ia: int, B: Polyhedron, eb: tuple[int, int], tol: float = 0.0,
              extent_tol: float = 0.0) -> Cover3 | None:
    """Exact vertex/edge cone and projection predicates, float construction."""
    a, p0 = _qvector(A.verts[ia]), _qvector(B.verts[eb[0]])
    d = _qedge(B, eb)
    w = sub(a, p0)
    s = dot(w, d) / dot(d, d)
    v = sub(w, mul(d, s))
    if not any(v):
        return None
    sb, sa = _qedge_contains(B, eb, v, tol), _qvertex_contains(A, ia, neg(v), tol)
    if sb < 0 or sa < 0:
        return None
    return Cover3("VE3", ("vertex", ia), ("edge", *eb), _qunit(v), norm(_float_vector(v)),
                  A.verts[ia], _float_vector(add(p0, mul(d, _qclamp(s)))), (float(s),), None,
                  sb == 1 and sa == 1, _qparameter_in_extent(s, d, extent_tol))


def ev3_cover(A: Polyhedron, ea: tuple[int, int], B: Polyhedron, ib: int, tol: float = 0.0,
              extent_tol: float = 0.0) -> Cover3 | None:
    """Exact edge/vertex cover, symmetric to vertex/edge."""
    c = ve3_cover(B, ib, A, ea, tol, extent_tol)
    if c is None:
        return None
    return Cover3("EV3", ("edge", *ea), ("vertex", ib), neg(c.normal), c.gap,
                  c.point_b, c.point_a, c.params, None, c.strict, c.in_extent)


def vv3_cover(A: Polyhedron, ia: int, B: Polyhedron, ib: int, tol: float = 0.0) -> Cover3 | None:
    """VV3 existence uses exact Gordan; activity uses the exact separation vector."""
    if not cones_intersect_relint(A, ia, B, ib):
        return None
    a, b = A.verts[ia], B.verts[ib]
    v = sub(_qvector(a), _qvector(b))
    if not any(v):
        return Cover3("VV3", ("vertex", ia), ("vertex", ib), None, 0.0, a, b, (), None, True, True)
    active = (_qvertex_contains(B, ib, v, tol) >= 0 and _qvertex_contains(A, ia, neg(v), tol) >= 0)
    return Cover3("VV3", ("vertex", ia), ("vertex", ib), _qunit(v), norm(_float_vector(v)),
                  a, b, (), None, True, active)


# Enumeration


def enumerate_covers3(A: Polyhedron, B: Polyhedron, *, window: float, tol: float = 0.0,
                      require_in_extent: bool = True, include_low_dim: bool = True,
                      extent_tol: float = 0.0) -> list[Cover3]:
    """当前位形下所有有效且在距离窗口内的三维盖。

    有效 = 法锥**闭**条件成立（判据 ≥ 0）；strict 只是盖上的一个字段，**任何一类盖都不按
    strict 过滤**。低维盖尤其不能过滤（2026-09-21 审查 C10 实测）：平行棱-棱最近对
    （EEP 退化，ee_cover 对平行棱返回 None）只由边界态 VE3/EV3 表达，一旦按 strict 过滤，
    margin.body_distance 的距离完备性就丢（tests/test_margin.py 三例红）。
    tol 是角度（法锥判据），extent_tol 是长度（in_extent 的边界带），见模块文档"容差"。
    """
    out: list[Cover3] = []
    for ia in range(len(A.verts)):
        for fb in range(len(B.faces)):
            c = vf_cover(A, ia, B, fb, tol, extent_tol)
            if c is not None and abs(c.gap) <= window and (c.in_extent or not require_in_extent):
                out.append(c)
    for fa in range(len(A.faces)):
        for ib in range(len(B.verts)):
            c = fv_cover(A, fa, B, ib, tol, extent_tol)
            if c is not None and abs(c.gap) <= window and (c.in_extent or not require_in_extent):
                out.append(c)
    for ea in A.edges():
        for eb in B.edges():
            c = ee_cover(A, ea, B, eb, tol, extent_tol)
            if c is not None and abs(c.gap) <= window and (c.in_extent or not require_in_extent):
                out.append(c)
    if include_low_dim:
        for ia in range(len(A.verts)):
            for eb in B.edges():
                c = ve3_cover(A, ia, B, eb, tol, extent_tol)
                if c is not None and abs(c.gap) <= window and (c.in_extent or not require_in_extent):
                    out.append(c)
        for ea in A.edges():
            for ib in range(len(B.verts)):
                c = ev3_cover(A, ea, B, ib, tol, extent_tol)
                if c is not None and abs(c.gap) <= window and (c.in_extent or not require_in_extent):
                    out.append(c)
        for ia in range(len(A.verts)):
            for ib in range(len(B.verts)):
                c = vv3_cover(A, ia, B, ib, tol)
                if c is not None and c.in_extent and c.gap <= window:
                    out.append(c)
    return out


def local_facets3(A: Polyhedron, B: Polyhedron, tol: float = 0.0) -> set[tuple]:
    """Strict local facets of the explicit exact convex views."""
    A, B = geom3.exact_convex_view(A), geom3.exact_convex_view(B)
    return set(_local_facets_cached(tuple(A.verts), tuple(A.faces), tuple(B.verts), tuple(B.faces),
                                   (_qnormal, _qedge, _qvertex_contains, _qedge_contains)))


@lru_cache(maxsize=128)
def _local_facets_cached(av, af, bv, bf, implementations):
    A, B = Polyhedron(list(av), list(af)), Polyhedron(list(bv), list(bf))
    out = []
    for ia in range(len(av)):
        for fb in range(len(bf)):
            if _qvertex_contains(A, ia, neg(_qnormal(B, fb))) == 1:
                out.append(("VF", ("vertex", ia), ("face", fb)))
    for fa in range(len(af)):
        for ib in range(len(bv)):
            if _qvertex_contains(B, ib, neg(_qnormal(A, fa))) == 1:
                out.append(("FV", ("face", fa), ("vertex", ib)))
    for ea in A.edges():
        for eb in B.edges():
            n = cross(_qedge(B, eb), _qedge(A, ea))
            if not any(n):
                continue
            for d in (n, neg(n)):
                if _qedge_contains(B, eb, d) == 1 and _qedge_contains(A, ea, neg(d)) == 1:
                    out.append(("EE", ("edge", *ea), ("edge", *eb)))
                    break
    return tuple(out)


def _facet_plane_on_views(A, B, label):
    kind, af, bf = label
    if kind == "VF":
        n = _qnormal(B, bf[1])
        a, b = A.verts[af[1]], B.verts[B.faces[bf[1]][0]]
    elif kind == "FV":
        n = neg(_qnormal(A, af[1]))
        a, b = A.verts[A.faces[af[1]][0]], B.verts[bf[1]]
    elif kind == "EE":
        ea, eb = (af[1], af[2]), (bf[1], bf[2])
        n = cross(_qedge(B, eb), _qedge(A, ea))
        if not any(n):
            raise ZeroDivisionError("parallel edges do not define an EE facet")
        if _qedge_contains(B, eb, n) < 0:
            n = neg(n)
        a, b = A.verts[af[1]], B.verts[bf[1]]
    else:
        raise ValueError(f"not a facet label: {label}")
    return n, sub(_qvector(b), _qvector(a))


def facet_plane3(A: Polyhedron, B: Polyhedron, label: tuple):
    """Exact (outward unnormalised normal, point on E support plane).

    Labels are indexed on exact_convex_view; the point b-a is never rounded.
    """
    return _facet_plane_on_views(geom3.exact_convex_view(A), geom3.exact_convex_view(B), label)


def facet_normal3(A: Polyhedron, B: Polyhedron, label: tuple) -> Vec3:
    """Float normal construction from the exact oriented facet plane."""
    n, _ = facet_plane3(A, B, label)
    return _qunit(n)


def facet_gap3(A: Polyhedron, B: Polyhedron, label: tuple, x: Vec3) -> float:
    """Float signed distance construction; never reused for classification."""
    n, p = facet_plane3(A, B, label)
    return float(dot(n, sub(_qvector(x), p)) / max(abs(t) for t in n)) / norm(
        tuple(float(t / max(abs(v) for v in n)) for t in n))


@lru_cache(maxsize=128)
def _support_planes_cached(av, af, bv, bf, labels, implementations):
    A, B = Polyhedron(list(av), list(af)), Polyhedron(list(bv), list(bf))
    aq, bq = tuple(map(_qvector, av)), tuple(map(_qvector, bv))
    out = []
    for fi in range(len(bf)):
        n = _qnormal(B, fi)
        a = min(aq, key=lambda x: dot(n, x))
        b = bq[bf[fi][0]]
        out.append((n, sub(b, a)))
    for fi in range(len(af)):
        n = neg(_qnormal(A, fi))
        a = aq[af[fi][0]]
        b = max(bq, key=lambda x: dot(n, x))
        out.append((n, sub(b, a)))
    # Caller-supplied labels are deliberately not sanitized: a false local
    # support plane must be exposed by the independent G0 membership vote.
    out.extend(_facet_plane_on_views(A, B, label) for label in labels)
    return tuple(out)


def _planes(A, B, facets):
    return _support_planes_cached(tuple(A.verts), tuple(A.faces), tuple(B.verts), tuple(B.faces), tuple(sorted(facets)),
                                  (_qnormal, _qedge, _qedge_contains))


def support_gaps3(A: Polyhedron, B: Polyhedron, x: Vec3) -> list[float]:
    """Face-support distances as constructions, not predicate inputs."""
    A, B = geom3.exact_convex_view(A), geom3.exact_convex_view(B)
    point = _qvector(x)
    out = []
    for n, p in _planes(A, B, ()):
        scale = max(abs(v) for v in n)
        out.append(float(dot(n, sub(point, p)) / scale) / norm(tuple(float(v / scale) for v in n)))
    return out


def membership_convex3(A: Polyhedron, B: Polyhedron, x: Vec3, tol: float = 0.0,
                       facets: set[tuple] | None = None, *, ang_tol: float = 1e-12) -> int:
    """Exact convex E membership: 1 inside / 0 boundary / -1 outside.

    Explicit positive tol requests the historical supporting-plane domain band
    (not a Euclidean offset). Comparisons to that band are rational and no
    rounding/noise floor is inserted. Zero tol gives the exact theorem predicate.
    """
    A, B = geom3.exact_convex_view(A), geom3.exact_convex_view(B)
    if facets is None:
        facets = local_facets3(A, B, 0.0)
    point = _qvector(x)
    boundary = False
    for n, p in _planes(A, B, facets):
        value = dot(n, sub(point, p))
        threshold2 = Fraction(max(0.0, tol)) ** 2 * dot(n, n)
        if value > 0 and value * value > threshold2:
            return -1
        if value >= 0 or value * value <= threshold2:
            boundary = True
    return 0 if boundary else 1
